setwd("C:/Users/IT24103240/Desktop/LAB_5")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE)
fix(Delivery_Times)
hist(Delivery_Time, main="Histogram for Delivery Times", breaks = seq(20, 70, length = 10), right = FALSE, xlab = "Delivery Time (minutes)")

histogram <- hist(Delivery_Time, main="Histogram for Delivery Times", breaks = seq(20, 70, length = 10), right = FALSE)

names(Delivery_Times) <- "Delivery_Time"
attach(Delivery_Times)
histogram <- hist(Delivery_Time, main="Histogram for Delivery Times", breaks = seq(20, 70, length = 10), right = FALSE)

new <- numeric(length(breaks))  

for(i in 1:length(breaks)){
  if(i==1){
    new[i] <- 0
  }else{
    new[i] <- cum.freq[i-1]
  }
}
plot(breaks, new, type='l', main="Cumulative Frequency Polygon for Delivery Times", 
     xlab="Delivery Time (minutes)", ylab="Cumulative Frequency", ylim=c(0, max(cum.freq)))
points(breaks, new, pch=16)  

cbind(Upper=breaks, CumFreq=new)