setwd("C:\\Users\\IT24103240\\Desktop\\IT24103240")

 pbinom(46, 50, 0.85, lower.tail = FALSE)

 dpois(15, 12)
