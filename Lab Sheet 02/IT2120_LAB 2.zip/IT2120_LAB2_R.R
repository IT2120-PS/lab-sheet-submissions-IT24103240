x <- c(1, 2, 3)
x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]

sum((1:15) %% 3 == 0)

vec <- c(10, 25, 3, 99, 45)
max_index <- 1
for (i in 2:length(vec)) {
  if (vec[i] > vec[max_index]) {
    max_index <- i
  }
}
print(max_index)

vec <- c(10, 25, 3, 99, 45)
which.max(vec)

