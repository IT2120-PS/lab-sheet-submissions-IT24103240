setwd("C:/Users/it24103240/Downloads/lab4ps")
branch_data <- read.table("exercise.txt", header = TRUE,sep=",")
print(branch_data)
str(branch_data)

boxplot(branch_data$Sales_X1,main = "bOX Plot of sales", ylab ="sales")
summary(branch_data$Advertising)
IQR(branch_data$Advertising)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower | x > upper]
  return(outliers)
}
  outliers_years <- find_outliers(branch_data$Years)
  print(outliers_years)
  
 
  